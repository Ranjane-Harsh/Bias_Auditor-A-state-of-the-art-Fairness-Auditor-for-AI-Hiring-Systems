# Bias Buster Pro Project Context

## Project Purpose
To evaluate, visualize, and mitigate bias in AI models used for hiring decisions, comparing fairness across models and sensitive attributes.

## Completed Modules
1. **Data Acquisition & Preprocessing**  
2. **Model Training & Validation**

## Remaining Modules and Updated Framework

### Module 3: Bias Detection & Fairness Evaluation
- Integrate AIF360 and Fairlearn for standardized fairness metrics.
- Compute group-based metrics: Demographic Parity, Equalized Odds, Equal Opportunity, Disparate Impact.
- Implement causal fairness checks with causal graphs and do-calculus.
- Use SHAP for subgroup explanation and discrepancy identification.
- Automate threshold selection for trade-off analysis.

### Module 4: Mitigation Techniques & Re-Evaluation
- **Pre-processing**: Reweighing, Disparate Impact Remover.
- **In-processing**: Adversarial Debiasing, Exponentiated Gradient Reduction (Fairlearn).
- **Post-processing**: Equalized Odds Post-processing, Calibration.
- Multi-objective optimization balancing accuracy and fairness via Lagrangian approach.
- Reinforce pipeline with iterative re-training and metric logging.

### Module 5: Interactive Reporting Dashboard
- Build with Streamlit/Dash for interactive web UI.
- Include dynamic plots (Plotly) of fairness metrics, ROC curves, and performance.
- Enable "what-if" scenario analysis for user to adjust thresholds.
- Export capabilities: PDF reports and PowerPoint slides.
- Containerize using Docker; set up CI/CD for automated model evaluation.

## Directory Structure
```
bias_buster_project/
├── module_1_data_acquisition/    # (existing)
├── module_2_model_training/      # from Code_zip.zip
├── module_3_fairness_evaluation/ # new
│   └── README.md
├── module_4_mitigation/          # new
│   └── README.md
├── module_5_dashboard/           # new
│   └── README.md
└── PROJECT_CONTEXT.md            # this file
```