# Module 3 Fairness Evaluation

## Bias Detection & Fairness Evaluation

See PROJECT_CONTEXT.md for full details.