# Module 4 Mitigation

## Mitigation Techniques & Re-Evaluation

See PROJECT_CONTEXT.md for full details.